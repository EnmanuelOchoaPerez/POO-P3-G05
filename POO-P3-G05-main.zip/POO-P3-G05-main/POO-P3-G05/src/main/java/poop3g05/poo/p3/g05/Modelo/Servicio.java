/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop3g05.poo.p3.g05.Modelo;

/**
 *
 * @author Rafael Cosmo
 */

import java.util.List;

public class Servicio {
    private int id;
    private String nombre;
    private double precio;
    private List<Insumo> insumos;

    public Servicio(int id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public List<Insumo> getInsumos() { return insumos; }
    public void setInsumos(List<Insumo> insumos) { this.insumos = insumos; }
    
    @Override
    public String toString() {
        return nombre + " - $" + precio;
    }
}